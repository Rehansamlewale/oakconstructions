import { motion, useScroll, useSpring } from 'framer-motion';

const ScrollProgress = () => {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  return (
    <motion.div
      className="fixed top-0 left-0 right-0 h-[2px] bg-luxury-gold origin-left z-[60] shadow-[0_0_10px_rgba(212,175,55,0.5)]"
      style={{ scaleX }}
    />
  );
};

export default ScrollProgress;
